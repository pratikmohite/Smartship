import React, { useState, useEffect } from 'react';
import './style.css';

function App() {
  let [photos, setphotos] = useState(null);

  
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/photos')
      .then((response) => response.json())
      
      .then((data) => setphotos(data));
  }, []);
  return (
    <div className="App">
      
      {photos &&
        photos.map((item) => (
          <a keys={item.id} href={item.url}>
            <img width={'200px'} height={'200px'} src={item.thumbnailUrl}></img>
          </a>
        ))}
    </div>
  );
}
export default App;







// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
